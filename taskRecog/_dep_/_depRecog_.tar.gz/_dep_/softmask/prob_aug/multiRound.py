
from taskRecog.util import Opt
from copy import deepcopy

import importlib

from taskRecog.softmask.prob_aug.ProbHardAugWrapper import WeightAugMaskTask as HardAug
from taskRecog.softmask.prob_aug.ProbSoftAugWrapper import WeightAugMaskTask as SoftAug
import os
from taskRecog.util import set_logger

class MutliRoundHardMask(Opt):
    def __init__(self, args):
        self.args = args
        
        if 'finetune' not in vars(self.args):
            self.args.finetune = False

        self.exp_module = importlib.import_module('{}.{}'.format(
            args.exp_config.replace('/', '.'), args.exp_file))
        
        self.data_config(args)
        self.exp_name = args.exp_name
        self.model_name = args.model
        
        if 'exp_dir' in vars(args) and args.exp_dir is not None:
            self.exp_dir = args.exp_dir
        else:
            assert 'exp_dataname_first' in vars(args)
            self.exp_dir = 'Exp_results' if args.test == False else 'Exp_Test'
            self.exp_dir = os.path.join(self.exp_dir, self.data_name, args.exp_name) if args.exp_dataname_first else os.path.join(self.exp_dir, args.exp_name, self.data_name)
            self.exp_name = args.exp_name        
    
    
    # def snrmodel_config(self, args):
    #     model_config = args.snrmodel.config
    #     model = importlib.import_module(model_config.import_path)
    #     model = getattr(model, model_config.class_name)
    #     model_config.hyper.num_classes = args.num_env
    #     model_config.hyper.merge(self.data_opts, ['sig_len'])
    #     if torch.cuda.is_available() and args.cuda:
    #         model_config.hyper.device = torch.device('cuda:{}'.format(args.gid))
    #     else:
    #         model_config.hyper.device = torch.device('cpu')
        
    #     model = model(model_config.hyper, self.logger)
    #     model_pt_file = os.path.join('Exp_results/SNR_Estimation', f'C{args.num_env}', self.data_name ,'fit', f'{args.snrmodel.name}', f'checkpoint/{self.data_name}_{args.snrmodel.name}.best.pt')
    #     model.load_pretraing_file(file_path =  model_pt_file)
    #     return model
        
        
    def data_config(self, args):
        # data_opts = getattr(self.exp_module, args.dataset + '_data')
        data_opts = getattr(self.exp_module, 'Data')
        self.data_opts = data_opts(args)
        self.data_name = self.data_opts.data_name                

    def logger_config(self, dir, stage):
        log_path = os.path.join(dir, 'logs',
                                '{}.{}.log'.format(stage,self.data_name))
        log_name = '{}.{}.{}'.format(
            self.exp_name,self.data_name, self.model_name)
        logger = set_logger(log_path, log_name, 20)
        return logger
    
    
    def task_config(self, args):
        task = HardAug(args)
        return task
    
    def conduct(self,):        
        self.logger = self.logger_config(self.exp_dir, f'{self.model_name}')
        # snrmodel = self.snrmodel_config(self.args)
        # snrmodel.eval()
        
        for i_iter in range(1, self.args.rounds+1):
            iter_args = deepcopy(self.args)
            iter_args.exp_name = self.args.exp_name+f'.iter{i_iter}'
            iter_args.exp_dir = os.path.join(self.exp_dir, f'iter{i_iter}')
      
            iter_hyper = Opt()
            if i_iter > 1:
                iter_hyper.pretraining_allDatafile = os.path.join(self.exp_dir, f'iter{i_iter -1}/fit/{self.model_name}/checkpoint/{self.data_name}_{self.model_name}.best.pt')
            iter_hyper.pretraining_file = os.path.join(self.exp_dir, f'iter{i_iter}/fit/{self.model_name}/checkpoint/{self.data_name}_{self.model_name}.best.pt')
            iter_hyper.sampler_file = os.path.join(self.exp_dir, f'iter{i_iter}/fit/{self.model_name}/sampler/snrs_step_mask.pt')
            # SnrPredTest.AMC/env2/RML2016.10a/SnrPredTest.AMC/env2.iter1/fit/awn/checkpoint/RML2016.10a_awn.best.pt
            iter_args.hyper = iter_hyper
          
            
            task = self.task_config(iter_args) # task = self.task_config(iter_args, snrmodel)
            score= taskRecog.conduct(force_update=self.args.force_update, finetune=self.args.finetune)
        
            val_acc= score.val_acc
            ori_acc = score.ori_acc
            refmask_acc = score.refmask_acc
            self.logger.info('Iter: {}\tVal. OA: {:.2f}%\tOri. OA: {:.2f}%\tRef. Mask OA: {:.2f}%'.format(i_iter, val_acc* 100, ori_acc * 100, refmask_acc * 100)) 
            # self.logger.info('Iter: {}\tOri. OA: {:.2f}%\tPred. Mask OA: {:.2f}%\tRef. Mask OA: {:.2f}%'.format(i_iter, ori_acc * 100, predmask_acc * 100, refmask_acc * 100))  
            
    def evaluate(self,):
        self.args.force_update = False
        
        self.logger = self.logger_config(self.exp_dir, f'{self.model_name}')

        acc_list = [['Iters','val_acc','ori acc', 'refmask acc']]
        
        import numpy as np
        acc_array = np.zeros(shape=(3, self.args.rounds))
        for i_iter in range(1, self.args.rounds+1):
            iter_args = deepcopy(self.args)
            iter_args.exp_name = self.args.exp_name+f'.iter{i_iter}'
            iter_args.exp_dir = os.path.join(self.exp_dir, f'iter{i_iter}')
      
            iter_hyper = Opt()
            if i_iter > 1:
                iter_hyper.pretraining_allDatafile = os.path.join(self.exp_dir, f'iter{i_iter -1}/fit/{self.model_name}/checkpoint/{self.data_name}_{self.model_name}.best.pt')
                
            # add to check!!!!!!!
            iter_hyper.pretraining_file = os.path.join(self.exp_dir, f'iter{i_iter}/fit/{self.model_name}/checkpoint/{self.data_name}_{self.model_name}.best.pt')
            iter_hyper.sampler_file = os.path.join(self.exp_dir, f'iter{i_iter}/fit/{self.model_name}/sampler/snrs_step_mask.pt')
            # SnrPredTest.AMC/env2/RML2016.10a/SnrPredTest.AMC/env2.iter1/fit/awn/checkpoint/RML2016.10a_awn.best.pt
            iter_args.hyper = iter_hyper
          
            
            task = self.task_config(iter_args)
            score= taskRecog.evaluate()
            
            val_acc= score.val_acc
            ori_acc = score.ori_acc
            refmask_acc = score.refmask_acc
            self.logger.info('Iter: {}\tVal. OA: {:.2f}%\tOri. OA: {:.2f}%\tRef. Mask OA: {:.2f}%'.format(i_iter, val_acc* 100, ori_acc * 100, refmask_acc * 100)) 
            
            cur_list = []
            cur_list.append('{}'.format(i_iter))
            cur_list.append('{:.2f}'.format(val_acc* 100))
            cur_list.append('{:.2f}'.format(ori_acc* 100))
            cur_list.append('{:.2f}'.format(refmask_acc* 100))
            acc_list.append(cur_list)
            acc_array[0, i_iter-1] = val_acc * 100
            acc_array[1, i_iter-1] = ori_acc * 100
            acc_array[2, i_iter-1] = refmask_acc* 100
        
        val_array = acc_array[0,:]
        _val = val_array[::-1]
        max_iter = len(_val) - np.argmax(_val) - 1
        max_val = acc_array[0, max_iter]
        max_ori = acc_array[1, max_iter]
        max_refmax = acc_array[2, max_iter]
        max_list = []
        max_list.append('{}'.format(max_iter + 1))
        max_list.append('{:.2f}'.format(max_val))
        max_list.append('{:.2f}'.format(max_ori))
        max_list.append('{:.2f}'.format(max_refmax))
        acc_list.append(max_list)
        
        acc_list = list(map(list, zip(*acc_list)))
        import numpy as np
        np.savetxt(os.path.join(self.exp_dir, 'logs', 'acc.{}.{}.csv'.format(self.model_name, self.data_name)), acc_list, delimiter=',', fmt='%s')
        
            
class MutliRoundSoftMask(MutliRoundHardMask):
    
    def task_config(self,args):
        task = SoftAug(args)
        return task            