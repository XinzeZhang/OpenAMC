import os
import sys

import torch
from taskRecog.util import Opt, set_dataloader
from taskRecog.Wrapper import Task
import numpy as np
from taskRecog.util import os_makedirs, os_rmdirs, chunk_list_nsub,set_logger, fix_seed
from tqdm import tqdm

from taskRecog.featureselection.snr_aware.softmaskTuner import maskTuner
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, cohen_kappa_score
from taskRecog.util import os_makedirs, os_rmdirs, set_logger, fix_seed
from taskRecog.util import save_training_process, save_confmat, save_snr_acc

class Mask(Opt):
    def __init__(self, init=None):
        super().__init__(init)
        self.local_dir = ''
        self.name = ''
        self.num_env = init.num_env
    
    def env_config(self, snrs, logger):
        num_snrs = len(snrs)
        if not  num_snrs % self.num_env == 0:
            logger.warning(f'Unequal class with num_env: {self.num_env} for total {num_snrs} SNR conditions.')
        
        snr_dict = {}
        
        env_list = chunk_list_nsub(snrs, self.num_env)
        
        for i, period in enumerate(env_list):
            logger.info(f'{i}-th snr env class with snr conditions: {period}')
            for snr in period:
                snr_dict[snr] = i
    
        self.snr_dict = snr_dict
        self.env_list = env_list

class SoftMaskTask(Task):
    """
    """
    def __init__(self, args):
        super().__init__(args)
        
        self.masking_tag = False
        self.sampler = Mask(args)
        self.sampler.local_dir = os.path.join(self.fit_dir, self.model_name, 'sampler')
        os_makedirs(self.sampler.local_dir)
        
        if 'sampler_file' in self.model_opts.hyper.dict and os.path.exists(self.model_opts.hyper.sampler_file):
            self.sampler.save_path = self.model_opts.hyper.sampler_file
        else:
            self.sampler.save_path = os.path.join(self.sampler.local_dir, f'snrs_step_mask.pt')    
         
        self.ori_result_path = os.path.join(self.model_pred_dir, 'results.ori.npz')
        self.mask_result_path = os.path.join(self.model_pred_dir, 'results.mask.npz')
                 

    def logger_config(self, dir, stage, name = None):
        log_path = os.path.join(dir, '{}.{}.log'.format(stage,self.data_name))
        log_name = '{}.{}.{}'.format(
            self.exp_name,self.data_name, self.model_name) if name is None else name
        logger = set_logger(log_path, log_name, self.logger_level)
        return logger
    

    def tuning(self):
        raise ValueError('Non support to tuning!')

    def snr_evoMask(self, snr_list = [0]):
        
        snr_zone_str = f'snr.{snr_list[0]}-{snr_list[-1]}' if len(snr_list) > 1 else f'snr.{snr_list[0]}'
        
        tuner_dir = os.path.join(self.model_fit_dir, 'SNR_tuner', snr_zone_str)
        
        os_makedirs(tuner_dir)
        self.model_opts.tuner.dir = tuner_dir
        tLogger = self.logger_config(dir=tuner_dir, stage= 'tuning', name=f'{self.model_opts.class_name}.{self.model_opts.tuner.algo_name}.{snr_zone_str}')
        
        snr_Tuner = maskTuner(self.model_opts, logger= tLogger, data_opts= self.data_opts, snr_list = snr_list)
        
        # step_idxs = snr_Tuner.conduct()
        step_idxs = snr_Tuner.meal_conduct()
        
        return step_idxs    
        

    def masking(self, logger): 
        self.sampler.env_config(self.data_opts.snrs, logger)
        if os.path.exists(self.sampler.save_path):
            # 'Exp_results/SnrAugAll3.Finetune/env4/RML2016.10a/iter1/fit/awn/sampler/snrs_step_mask.pt'
        # if False: #toDo: this is set to re-save the sampler results.
            snrs_step_mask = torch.load(self.sampler.save_path)
            assert len(snrs_step_mask) == self.sampler.num_env  
            logger.info('-'*80)
            logger.info(f'Read the saved snrs_step_mask from {self.sampler.save_path} successfully!')
        else:            
            logger.info('*'*80)
            logger.info(f'Process the sampling with {self.model_opts.tuner.algo} for every step on every env.')
            
            with tqdm(total = len(self.sampler.env_list), desc='SNR_Env.', mininterval=0.3, colour='red') as pbar:
                snrs_step_mask = []
                for step, snr_list in enumerate(self.sampler.env_list):
       
                    step_idxs = self.snr_evoMask(snr_list)
                    snrs_step_mask.append(step_idxs)
                    
                    pbar.update(1)
            
            os_makedirs(self.sampler.local_dir)
            torch.save(snrs_step_mask, self.sampler.save_path)
            logger.info(f'Save the snrs_step_mask to {self.sampler.save_path} !')

        self.sampling_tag = True
        
        # snrs_step_mask
        for env,  step_idxs in enumerate(snrs_step_mask):
            logger.info(f'Env: {self.sampler.env_list[env]}\t Mask step idxs: {step_idxs}')
            
        return snrs_step_mask
    
    
    def sampling_dataset(self, data_set, data_idx, data_tag = 'train'):
        Signals, Labels = data_set
        
        data_sampling_set = Signals.detach().clone()
        
        from taskRecog.util import snr_slice
        self.logger.info(f'Masking the dataset {Signals.size()} with snrs_masks')
        for snr_list, step_idxs in tqdm(zip(self.sampler.env_list, self.snrs_mask_idxs), total=len(self.snrs_mask_idxs)):
            for snr in snr_list:
                sig_i, _, idx_i = snr_slice(data_set, data_idx, self.data_opts.SNRs, snr)
                _sig_i = sig_i.mul(torch.tensor(step_idxs))
                # for step, value in enumerate(step_idxs):
                #     sig_i[:,:, step] = sig_i[:,:, step].detach().clone() * value    
                data_sampling_set[idx_i] = _sig_i
                
        return data_sampling_set, Labels
            
    
    def load_fitset(self, cid_hyper=None):
        batch_size = 64 if cid_hyper is None else cid_hyper.batch_size
        
        if 'snrs_mask_idxs' not in self.dict:
             raise ValueError('Non sampling stage! Please run sampling function first.')
         
        train_set = self.sampling_dataset(self.data_opts.train_set, self.data_opts.train_idx, 'train')
        val_set = self.sampling_dataset(self.data_opts.val_set, self.data_opts.val_idx,'valid')
        
        train_loader = set_dataloader(batch_size= batch_size, data_set=train_set)
        val_loader = set_dataloader(batch_size= batch_size, data_set=val_set)
        
        return train_loader, val_loader

    def snr_testset(self, batch_size, test_set):
        Sample_list = []
        Label_list = []
        
        for snr in self.data_opts.snrs:
            sig_i, lab_i, _ = self.data_opts.snr_slice('test', snr)

            num_chunk = int(sig_i.shape[0] / batch_size)

            Sample = torch.chunk(sig_i, num_chunk, dim=0)
            Label = torch.chunk(lab_i, num_chunk, dim=0)  

            Sample_list.append(Sample)
            Label_list.append(Label)
        
        return Sample_list, Label_list

    def load_testset(self, cid_hyper=None):
        batch_size = 64 if cid_hyper is None else cid_hyper.batch_size
        test_set = self.sampling_dataset(self.data_opts.test_set, self.data_opts.test_idx, 'test')
        Sample_list, Label_list = self.snr_testset(batch_size, test_set)
        
        return Sample_list, Label_list

    def conduct(self, force_update=None, ):
        if force_update is not None:
            if force_update in [True, False]:
                self.force_update = force_update
            else:
                raise ValueError(
                    'force_update parameter is incorrect, please set with True or False.')

        result_statue = os.path.exists(self.ori_result_path) and os.path.exists(self.mask_result_path)
        
        self.logger = self.logger_config(
            self.model_fit_dir, 'train')
        self.load_data(logger=self.logger)
        
        self.snrs_mask_idxs = self.masking(logger=self.logger)
        
        
        if not result_statue or self.force_update:
            if result_statue:
                os_rmdirs(self.model_pred_dir)
            os_makedirs(self.model_pred_dir)


            self.conduct_fit(clogger=self.logger)

            self.fit_statue = True

            ori_acc, pred_mask_acc = self.evaluate(elogger=self.logger) # toDo: add eval dir with sampler.num_steps tag
        else:
            ori_acc, pred_mask_acc = self.evaluate()
            
        return ori_acc, pred_mask_acc


    def conduct_fit(self, clogger = None, finetune = False, xfit_stats = True):
        try:
            if clogger is None:
                clogger = self.logger_config(
                    self.model_fit_dir, 'train')
                        
            cid_hyper = self.load_hyper(clogger)
            train_loader, val_loader = None, None
            if xfit_stats:
                train_loader, val_loader = self.load_fitset(cid_hyper)
                clogger.critical('Loading training set and validation set.')
                clogger.info(f'Fit batch size: {train_loader.batch_size}')
                clogger.info(f"Train_loader batch: {len(train_loader)}")
                clogger.info(f"Val_loader batch: {len(val_loader)}")
                clogger.critical('>'*40)

            if finetune:
                cid_hyper.pretraining_file = cid_hyper.pretraining_allDatafile
            else:
                cid_hyper.pretraining_file = ''
                
            model = self.model_import()
            model = model(cid_hyper, clogger) #todo: check model_fit_dir in model and model trainer
            clogger.critical('Loading Model.')
            clogger.critical(f'Model: \n{str(model)}')

            # if self.model_opts.arch == 'torch_nn':
            clogger.info(">>> Total params: {:.2f}M".format(
                    sum(p.numel() for p in list(model.parameters())) / 1000000.0))         
    
            clogger.critical('Start fit.')
            
            
            epochs_stats =  model.xfit(train_loader, val_loader,finetune = finetune,xfit_stats=xfit_stats) 
                     
            if epochs_stats is not None and set(['val_loss','val_acc', 'train_loss', 'train_acc', 'lr_list']).issubset(epochs_stats.columns):
                loss_dir = os.path.join(self.model_fit_dir, 'loss_curve')
                lossfig_dir = os.path.join(loss_dir, 'figure')
                save_training_process(epochs_stats, plot_dir=lossfig_dir)
            
            # generate the output of the testset

            clogger.critical('>'*40)
            clogger.critical('End fit.')
            (pre_lab_all, label_all), (_pre_lab_all, _label_all) = self.eval_testset(model, clogger)
        
            return (pre_lab_all, label_all), (_pre_lab_all, _label_all), epochs_stats
            
        except:
            clogger.exception(
                '{}\nGot an error on conduction.\n{}'.format('!'*50, '!'*50))
            raise SystemExit()    
    

    def eval_testset(self, model, logger):

        def eval_samples(model, sample_list, label_list):
            pre_lab_all = []
            label_all = []
            # loop of SNRs in test_sample_list
            for (Sample, Label) in tqdm(zip(test_sample_list, test_lable_list), total=len(test_sample_list)):
                pred_i = []
                label_i = []
                for (sample, label) in zip(Sample, Label):
                    pre_lab = model.predict(sample)
                    pred_i.append(pre_lab)
                    label_i.append(label)
                pred_i = np.concatenate(pred_i)
                label_i = np.concatenate(label_i)
                
                pre_lab_all.append(pred_i)
                label_all.append(label_i)
            
            return pre_lab_all, label_all

        model.eval()
        logger.critical('>'*40)
        logger.critical('Evaluation on the original testing set.')
            
        batch_size = 64 if 'batch_size' not in model.hyper.dict else model.hyper.batch_size
        test_sample_list, test_lable_list = self.data_opts.load_testset(test_batch_size = batch_size)
        
        pre_lab_all, label_all = eval_samples(model, test_sample_list, test_lable_list)
        tgt_result_file = self.ori_result_path
        
        np.savez(tgt_result_file, pred = pre_lab_all, label= label_all)
        logger.critical('Save result file to the location: {}'.format(tgt_result_file))
        # logger.critical('-'*80)   
            
        logger.critical('>'*40)
        logger.critical('Evaluation on the pred_masking testing set.')
        test_sample_list, test_lable_list = self.load_testset(model.hyper)
        
        _pre_lab_all, _label_all = eval_samples(model, test_sample_list, test_lable_list)
        tgt_result_file = self.mask_result_path
        
        np.savez(tgt_result_file, pred = _pre_lab_all, label= _label_all)
        logger.critical('Save result file to the location: {}'.format(tgt_result_file))
        logger.critical('-'*80)   

                
        return (pre_lab_all, label_all), (_pre_lab_all, _label_all)


    def record_result(self,pre_lab_all, label_all, tag, ave_confMax):
        
        Confmat_Set = np.zeros((len(self.data_opts.num_snrs), self.data_opts.num_classes, self.data_opts.num_classes), dtype=int)
        Accuracy_list = np.zeros(len(self.data_opts.num_snrs), dtype=float)
        
        for snr_i, (pred_i, label_i) in enumerate(zip(pre_lab_all, label_all)):
            cm_i =  confusion_matrix(label_i, pred_i)
            Confmat_Set[snr_i, :, :] = cm_i
            Accuracy_list[snr_i] = accuracy_score(label_i, pred_i)
    
        pre_lab_all = np.concatenate(pre_lab_all)
        label_all = np.concatenate(label_all)
        
        F1_score = f1_score(label_all, pre_lab_all, average='macro')
        kappa = cohen_kappa_score(label_all, pre_lab_all)
        acc = np.mean(Accuracy_list)
        
        self.logger.info(f'On the {tag} testing datset:')
        self.logger.info('Overall Accuracy is: {:.2f}%'.format(acc * 100))
        self.logger.info(f'Macro F1-score is: {F1_score:.4f}')
        self.logger.info(f'Kappa Coefficient is: {kappa:.4f}')
        
        save_dir = os.path.join(self.eval_plot_dir, tag)
        if ave_confMax:
            save_confmat(Confmat_Set, self.data_opts.num_snrs, self.data_opts.classes, save_dir)

        Accuracy_Mods = save_snr_acc(Accuracy_list, Confmat_Set, self.data_opts.num_snrs, self.data_name, self.data_opts.classes.keys(), save_dir)
        
        tgt_acc_file = os.path.join(self.eval_acc_dir, f'acc.{tag}.npz')
        np.savez(tgt_acc_file, acc_overall = Accuracy_list, acc_mods= Accuracy_Mods)
        self.logger.info('Save accuracy file to the location: {}'.format(tgt_acc_file))
        
        return acc

    def evaluate(self, elogger = None, xfit_stats=False, ave_confMax = False):
        
        if elogger is None:
            self.logger = set_logger(os.path.join(self.eval_dir, '_log_', '{}.{}.eval.log'.format(self.data_name, self.model_name)), '{}.{}'.format(
                self.data_name, self.model_name.upper()), self.logger_level) 
            
        if self.data_statue is False:
            self.load_data(logger=self.logger)
            self.snrs_mask_idxs = self.masking(logger=self.logger)
        
        self.model_eval_dir = os.path.join(self.eval_dir, self.model_name)
        self.eval_acc_dir = os.path.join(self.model_eval_dir, 'accuracy')
        self.eval_plot_dir = os.path.join(self.model_eval_dir, 'figures')
        
        os_makedirs(self.eval_acc_dir)
        os_makedirs(self.eval_plot_dir)
        os_makedirs(self.model_pred_dir)
        
        # for i in self.cid_list: # multiple cross validation in the future version
        
        if self.args.force_update is False:
            force_update = False
        else:
            force_update = True
        
        ori_result_path = os.path.join(self.model_pred_dir, 'results.ori.npz')
        mask_result_path = os.path.join(self.model_pred_dir, 'results.mask.npz')
        
        if force_update is False and os.path.exists(ori_result_path) and os.path.exists(mask_result_path):
            with np.load(ori_result_path) as data:
                pre_lab_all, label_all = data['pred'], data['label']
            with np.load(mask_result_path) as data:
                _pre_lab_all, _label_all = data['pred'], data['label']
        else:
            (pre_lab_all, label_all), (_pre_lab_all, _label_all), _ = self.conduct_fit(xfit_stats = xfit_stats)
            
        ori_acc = self.record_result(pre_lab_all, label_all, 'ori',ave_confMax)
        mask_acc = self.record_result(_pre_lab_all, _label_all, 'mask',ave_confMax)
        
        return ori_acc, mask_acc
        
            
class CodeCheckTask(SoftMaskTask):
    """This task is designed to check the proposed SoftMask. When the snrs_step_mask are all set as 1, which means the training set, validation set, and testing set of the SoftMaskTask should be preserved as the same as them in base.Wrapper.\n
    Thus using the same pretraining model file for a model, the testing results should also be same.\n
    If there is any difference, the SoftMaskTask changed the datasets.\n
    However, with our carefully double check, there is non difference, the SoftMaskTask runs clean.
    """

    def __init__(self, args):
        super().__init__(args)
        

    def masking(self, logger): 

        # return snrs_step_mask
        snrs_step_mask = []
        for step, snr in enumerate(self.data_opts.snrs):
            step_idxs = [1 for i in range(self.data_opts.info.sig_len)]
            snrs_step_mask.append(step_idxs)
            
        for snr,  step_idxs in enumerate(snrs_step_mask):
            logger.info(f'SNR: {self.data_opts.snrs[snr]}\t Mask step idxs: {step_idxs}')
            
        return snrs_step_mask