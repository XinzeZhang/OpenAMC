import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), os.path.pardir))

import torch
import torch.utils.data as Data

from taskRecog.util import Opt


import importlib

from taskRecog.util import os_rmdirs,set_logger,set_fitset,set_dataloader
from taskRecog.Tuner import HyperTuner

from random import sample
import numpy as np
from copy import deepcopy
from numpy.random import uniform

def trial_str_creator(trial):
    return "{}_{}".format(trial.trainable_name, trial.trial_id)

def sigmoid_act(v):
    sv = 1 / (1+np.exp(-v))
    x = 1.0 if uniform(0, 1) > sv else 0.0
    return x

def mask_float(data_set, mask_op):
    '''
    data_set:(data, label)\n
    data:  torch.tensor (sample, dims, steps)\n
    im_op: list lens== steps
    '''
    data, label = data_set
    _data = data.detach().clone()

    for id, v in enumerate(mask_op):
        _data[:,:, id] = _data[:,:, id].detach().clone() * v

    new_data_set = (_data, label)
    
    return new_data_set

class maskTuner(HyperTuner):
    def __init__(self, opts = None, logger= None, data_opts = None, snr_list = None):
        super().__init__(opts, logger, data_opts)
        self.snr_list = snr_list
        self.batch_size = 1024 if 'batch_size' not in vars(self.tuner) else self.tuner.batch_size

    def meal_conduct(self,):
        # tuner_algo_dir = os.path.join(self.tuner.dir, self.algo_name)
        func_data = self.pack_data()
        
        pop_size = self.tuner.pop_size if 'pop_size' in vars(self.tuner) else 20
        maxCycle = self.tuner.maxCycle if 'maxCycle' in vars(self.tuner) else 10
        
        self.logger.info('*'*50)
        self.logger.info(f'Start evolve the input masks by algo: {self.tuner.algo_name} with pop_size {pop_size} and maxCycle {maxCycle}')
        swarm = PO(pop_size=pop_size,maxCycle=maxCycle,func_data=func_data,save_dir=self.tuner.dir)
        
        config, Maskcode = swarm.evolve()
        self.logger.info(f'Masks value: {Maskcode}')
        # for i, t in enumerate(Maskcode): 
        #     self.logger.info(f'inputMasks_{i}: {t}')
        return Maskcode


    def pack_data(self):
        # train_sig, train_label, _ = self.data_opts.snr_slice('train', snr)
        val_sig_list, val_lab_list = [], []
        for snr in self.snr_list:
            val_sig, val_lab, _ = self.data_opts.snr_slice('val', snr)
            val_sig_list.append(val_sig)
            val_lab_list.append(val_lab)

        val_sig_list = torch.cat(val_sig_list, dim=0)
        val_lab_list = torch.cat(val_lab_list, dim=0)
        func_data = Opt()
        func_data.logger = self.logger
        func_data.merge(self,['hyper', 'import_path', 'class_name', 'trainer_module','batch_size'])
        # func_data.train_set = (None, None)
        func_data.val_set = (val_sig_list, val_lab_list)

        return func_data

class Praticle2fitness:
    def setup(self, data = None) -> None:
        self.init_data(data)

    def step(self,):
        self.trainer.before_val_step(logging =False)
        for step, (sig_batch, lab_batch) in enumerate(self.trainer.val_loader):
            with torch.no_grad():
                sig_batch = sig_batch.to(self.trainer.hyper.device)
                lab_batch = lab_batch.to(self.trainer.hyper.device)

                loss, acc = self.trainer.cal_loss_acc(sig_batch, lab_batch)
                self.trainer.val_acc.update(acc)
        
        v_acc = self.trainer.val_acc.avg
        # self.logger.info('Val Acc: {:.3f}%'.format(v_acc * 100 ))
        
        return {
            'val_acc': v_acc,
            'best_val_acc': v_acc * 100, 
        }
    
    def init_data(self, data):
        self.valid_data = data.val_set
        self.sample_hyper = data.hyper
        self.import_path = data.import_path
        self.class_name = data.class_name
        self.logger = data.logger
        self.batch_size = data.batch_size
        # if 'logdir' not in self.__dict__:
        #     self.logdir = data.logdir

        # from pathlib import PurePath
        # p = PurePath(self.logdir)
        # p = p.parts
        
        # logger_path = os.path.join(self.logdir, '{}.log'.format(self.class_name))
        # self.logger = set_logger(logger_path, f'{self.class_name}.{p[-1]}.{p[-2]}', rewrite=False)
        self.problem_dim = self.sample_hyper.sig_len
        
        # self.num_workers = 0 if 'num_workers' not in self.sample_hyper.dict else  self.sample_hyper.num_workers        
        _model = importlib.import_module(self.import_path)
        _model = getattr(_model, self.class_name)
        sample_model = _model(self.sample_hyper, self.logger)
        
        self.logger.critical('Loading Model.')
        self.logger.critical(f'Model: \n{str(sample_model)}')
        self.logger.info(">>> Total params: {:.2f}M".format(
                    sum(p.numel() for p in list(sample_model.parameters())) / 1000000.0))
        self.logger.critical('Start fit.')
            
        trainer = importlib.import_module(data.trainer_module[0])
        trainer = getattr(trainer, data.trainer_module[1])
        
        val_loader = set_dataloader(batch_size= self.batch_size, data_set=self.valid_data)
        
        self.logger.critical('Loading training set and validation set.')
        # self.logger.info(f"Train_loader batch: {len(train_loader)}")
        self.logger.info(f"Val_loader batch: {len(val_loader)}")
        self.logger.critical('>'*40)
        self.logger.info(f'Finding pretraining file in the location {self.sample_hyper.pretraining_allDatafile}')
        sample_model.load_pretraing_file(file_path=self.sample_hyper.pretraining_allDatafile)
        
        self.trainer = trainer(model = sample_model, train_loader = None, val_loader = val_loader, cfg = self.sample_hyper, logger = self.logger)
        # self.trainer.hyper.patience = self.trainer.hyper.epochs # Actually, in TuningCell, patience does not work as the same as in trainer.
        self.trainer.before_train()
    
    def reset_config(self, new_config):
        _config = Opt()
        _config.merge(new_config, ['inputMask_{}'.format(i) for i in range(self.sample_hyper.sig_len)])
        # torch.save(_config, os.path.join(self.logdir, 'hyper.pt'))
        
        inputMask = [_config.dict['inputMask_{}'.format(i)] for i in range(self.sample_hyper.sig_len)]
        val_set = mask_float(self.valid_data, inputMask)
        val_loader = set_dataloader(batch_size= self.batch_size, data_set=val_set)
        # self.logger.info(f"Reset config! Val_loader batch: {len(val_loader)}")
        # self.logger.critical('>'*40)
        self.trainer.val_loader = val_loader
                
        return True
        
class PO():
    def __init__(self, pop_size = 20, maxCycle = 20, func_data = None, save_dir = None, metric = 'val_acc', patience = 10, algo = 'clpso'):
        self.pop_size = pop_size
        self.maxCycle = maxCycle

        self.problem_dims = func_data.hyper.sig_len
    
        self.func_data = func_data
        
        self.save_dir = save_dir # to use
        # self.tuning_dict = tuning_dict
        
        self.logger = func_data.logger

        self.peval = Praticle2fitness()
        self.peval.setup(data=self.func_data)
        

        self.fitness_metric = metric
        self.patience = patience       
        self.algo = algo  
        self.starting_perturb = [0.05, 0.1, 0.15, 0.2, 0.25,0.5,0]
        
    def create_starting_solutions(self,):
        '''return starting_solutions, shape: (pop_size, problem_dim)'''
        from random import sample
        from math import ceil
        
        def chunk_into_n(lst, n):
            size = ceil(len(lst) / n)
            return list(
                map(lambda x: lst[x * size:x * size + size],
                list(range(n)))
            )
        
        num_div = len(self.starting_perturb)
        pop_list = list(range(self.pop_size))
        init_list = chunk_into_n(lst=pop_list, n=num_div)
        
        
        idx_list = [i for i in range(self.problem_dims)]
        
        all_pop = []
        for i_pop_list, p_ratio in zip(init_list, self.starting_perturb):
            for i in i_pop_list:
                num_p = int(self.problem_dims * p_ratio)
                selected_idx = sample(idx_list, num_p)
                i_solution = np.ones(self.problem_dims)
                i_solution[selected_idx] = 0
                all_pop.append(i_solution)
        
        # # making the last starting pop is all selected
        # i_solution = np.ones(self.problem_dims)
        # all_pop[-1] = i_solution
        
        assert len(all_pop) == self.pop_size
        starting_solutions = np.stack(all_pop, axis = 0)
        return starting_solutions
    
    
    def evolve(self,):
        def fitness_function(solution):
            config = {}
            for i in range(self.problem_dims):
                state_i = solution[i]
                rand = uniform(0, 1)
                if state_i > rand:
                    config['inputMask_{}'.format(i)] = 1
                else:
                    config['inputMask_{}'.format(i)] = 0
                
            self.peval.reset_config(config)
            results = self.peval.step()
            fitness = results[self.fitness_metric]
            
            return fitness
                
        results_pt = os.path.join(self.save_dir, 'hyper.tuning.pt' )
        if os.path.exists(results_pt):
            self.logger.info(f'Loading pre-tuning result from {results_pt}')
            config = torch.load(results_pt)
        else:
            problem = {
                "fit_func": fitness_function,
                "lb": [0 for i in range(self.problem_dims)],
                "ub": [1 for i in range(self.problem_dims)],
                "minmax": "max",
                'verbose': False,
                # 'log_to': "file",
                # 'log_file': self.logger.handlers[0].baseFilename
            }
            
            term_dict = {
            "max_early_stop": self.patience   # after 30 epochs, if the global best doesn't improve then we stop the program
            }
            
            if self.algo == 'clpso':
                from mealpy.swarm_based import PSO
                algo_func = PSO.CL_PSO(epoch=self.maxCycle,pop_size=self.pop_size)
                
                # from mealpy import TLO
                # algo_func = TLO.OriginalTLO(epoch=self.maxCycle,pop_size=self.pop_size)
                # Liang, J.J., Qin, A.K., Suganthan, P.N. and Baskar, S., 2006. Comprehensive learning particle swarm optimizer for global optimization of multimodal functions. IEEE transactions on evolutionary computation, 10(3), pp.281-295.
            elif self.algo == 'aro':
                from mealpy.swarm_based import ARO
                algo_func = ARO.OriginalARO(epoch=self.maxCycle,pop_size=self.pop_size)
                # Wang, L., Cao, Q., Zhang, Z., Mirjalili, S., & Zhao, W. (2022). Artificial rabbits optimization: A new bio-inspired meta-heuristic algorithm for solving engineering optimization problems. Engineering Applications of Artificial Intelligence, 114, 105082.
            
            s_solutions = self.create_starting_solutions()
            algo_func.solve(problem, termination=term_dict, starting_positions=s_solutions)
            best_solution = algo_func.solution[0]
            config = Opt()
            
            for i in range(self.problem_dims):
                state_i = best_solution[i]
                rand = uniform(0, 1)
                cur = 1 if state_i > rand else 0
                config.dict[f'inputMask_{i}'] = cur
    
            results_pt = os.path.join(self.save_dir, 'hyper.tuning.pt' )
            torch.save(config, results_pt)
            self.logger.info(f'Saving tuning result to {results_pt}')
        
        Maskcode = [config.dict[f'inputMask_{i}'] for i in range(self.problem_dims)]
        
        return config, Maskcode        
    
# New version of maskTuner
# class maskTuner(Opt):
#     def __init__(self, opts = None, logger= None, data_opts = None, snr_list = None):
#         super().__init__()
        
#         if opts is not None:
#             self.merge(opts)
            
#         self.logger = logger
#         self.data_opts = data_opts
        
#         self.snr_list = snr_list
#         self.batch_size = 1024 if 'batch_size' not in vars(self.tuner) else self.tuner.batch_size

#     def meal_conduct(self,):
#         # tuner_algo_dir = os.path.join(self.tuner.dir, self.algo_name)
#         func_data = self.pack_data()
        
#         pop_size = self.tuner.pop_size if 'pop_size' in vars(self.tuner) else 20
#         maxCycle = self.tuner.maxCycle if 'maxCycle' in vars(self.tuner) else 10
        
#         self.logger.info('*'*50)
#         self.logger.info(f'Start evolve the input masks by algo: {self.tuner.algo_name} with pop_size {pop_size} and maxCycle {maxCycle}')
        
#         config, Maskcode = self.optimizer(pop_size=pop_size,maxCycle=maxCycle,func_data=func_data,save_dir=self.tuner.dir)
#         self.logger.info(f'Masks value: {Maskcode}')
#         # for i, t in enumerate(Maskcode): 
#         #     self.logger.info(f'inputMasks_{i}: {t}')
#         return Maskcode
    
#     def optimizer(self, pop_size, maxCycle, func_data, save_dir, metric = 'val_acc', patience = 10, algo = 'clpso'):
#         self.pop_size = pop_size
#         self.maxCycle = maxCycle

#         self.problem_dims = self.hyper.sig_len
#         self.func_data = func_data
#         self.save_dir = save_dir
        
#         self.peval = Praticle2fitness()
#         self.peval.setup(data=self.func_data)
#         self.fitness_metric = metric 
#         self.algo = algo  
#         self.starting_perturb = [0.05, 0.1, 0.15, 0.2, 0.25,0.5,0]
        
#         results_pt = os.path.join(self.save_dir, 'hyper.tuning.pt' )
#         if os.path.exists(results_pt):
#             self.logger.info(f'Loading pre-tuning result from {results_pt}')
#             config = torch.load(results_pt)
#         else:
#             problem = {
#                 "fit_func": self.fitness_function,
#                 "lb": [0 for i in range(self.problem_dims)],
#                 "ub": [1 for i in range(self.problem_dims)],
#                 "minmax": "max",
#                 'verbose': False, # 'log_to': "file", 'log_file': self.logger.handlers[0].baseFilename
#             }
            
#             term_dict = {
#             "max_early_stop": patience   # after 30 epochs, if the global best doesn't improve then we stop the program
#             }
            
#             if self.algo == 'clpso':
#                 from mealpy.swarm_based import PSO
#                 algo_func = PSO.CL_PSO(epoch=self.maxCycle,pop_size=self.pop_size) # Liang, J.J., Qin, A.K., Suganthan, P.N. and Baskar, S., 2006. Comprehensive learning particle swarm optimizer for global optimization of multimodal functions. IEEE transactions on evolutionary computation, 10(3), pp.281-295.
#             elif self.algo == 'aro':
#                 from mealpy.swarm_based import ARO
#                 algo_func = ARO.OriginalARO(epoch=self.maxCycle,pop_size=self.pop_size)# Wang, L., Cao, Q., Zhang, Z., Mirjalili, S., & Zhao, W. (2022). Artificial rabbits optimization: A new bio-inspired meta-heuristic algorithm for solving engineering optimization problems. Engineering Applications of Artificial Intelligence, 114, 105082.
            
#             s_solutions = self.create_starting_solutions( starting_perturb= self.starting_perturb, pop_size=self.pop_size, problem_dims=self.problem_dims)
#             algo_func.solve(problem, termination=term_dict, starting_positions=s_solutions)
#             best_solution = algo_func.solution[0]
#             config = Opt()
            
#             for i in range(self.problem_dims):
#                 state_i = best_solution[i]
#                 rand = uniform(0, 1)
#                 cur = 1 if state_i > rand else 0
#                 config.dict[f'inputMask_{i}'] = cur
    
#             results_pt = os.path.join(self.save_dir, 'hyper.tuning.pt' )
#             torch.save(config, results_pt)
#             self.logger.info(f'Saving tuning result to {results_pt}')
        
#         Maskcode = [config.dict[f'inputMask_{i}'] for i in range(self.problem_dims)]

#         return config, Maskcode  
    
#     def create_starting_solutions(self,starting_perturb = [0.05, 0.1, 0.2,0.5,0],pop_size = 20, problem_dims = 168, ):
#         '''return starting_solutions, shape: (pop_size, problem_dim)'''
#         from random import sample
        
#         num_div = len(starting_perturb)
#         pop_list = list(range(pop_size))
#         init_list = chunk_list_nsub(lst=pop_list, n=num_div)
        
#         idx_list = [i for i in range(problem_dims)]
#         all_pop = []
#         for i_pop_list, p_ratio in zip(init_list, starting_perturb):
#             for i in i_pop_list:
#                 num_p = int(problem_dims * p_ratio)
#                 selected_idx = sample(idx_list, num_p)
#                 i_solution = np.ones(problem_dims)
#                 i_solution[selected_idx] = 0
#                 all_pop.append(i_solution)
    
#         assert len(all_pop) == pop_size
#         starting_solutions = np.stack(all_pop, axis = 0)
#         return starting_solutions
    
#     def fitness_function(self, solution):
#         config = {}
#         for i in range(self.problem_dims):
#             state_i = solution[i]
#             rand = uniform(0, 1)
#             if state_i > rand:
#                 config['inputMask_{}'.format(i)] = 1
#             else:
#                 config['inputMask_{}'.format(i)] = 0
            
#         self.peval.reset_config(config)
#         results = self.peval.step()
#         fitness = results[self.fitness_metric]
        
#         return fitness


#     def pack_data(self):
#         # train_sig, train_label, _ = self.data_opts.snr_slice('train', snr)
#         val_sig_list, val_lab_list = [], []
#         for snr in self.snr_list:
#             val_sig, val_lab, _ = self.data_opts.snr_slice('val', snr)
#             val_sig_list.append(val_sig)
#             val_lab_list.append(val_lab)

#         val_sig_list = torch.cat(val_sig_list, dim=0)
#         val_lab_list = torch.cat(val_lab_list, dim=0)
#         func_data = Opt()
#         func_data.logger = self.logger
#         func_data.merge(self,['hyper', 'import_path', 'class_name', 'trainer_module','batch_size'])
#         # func_data.train_set = (None, None)
#         func_data.val_set = (val_sig_list, val_lab_list)

#         return func_data    