import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), os.path.pardir))

import torch
import torch.utils.data as Data

import ray
from taskRecog.util import Opt
# from ray.tune.suggest.bohb import TuneBOHB
# from ray.tune.schedulers import HyperBandForBOHB
from ray.tune.schedulers import ASHAScheduler
from ray.tune.schedulers import PopulationBasedTraining 
# https://arxiv.org/pdf/1711.09846.pdf.
from ray.tune.schedulers.pb2 import PB2 
# pip install GPy sklearn
# https://arxiv.org/abs/2002.02518 (NIPS 2020)
from ray import tune
from ray.air import session, FailureConfig
from ray.air.config import RunConfig
from ray.air.config import CheckpointConfig
# from ray.air.checkpoint import Checkpoint

from ray.tune.search.nevergrad import NevergradSearch
from ray.tune.search.ax import AxSearch
from ray.tune.search.optuna import OptunaSearch
from ray.tune.search import ConcurrencyLimiter
from ray.tune.search.basic_variant import BasicVariantGenerator
from ray.tune import ExperimentAnalysis

import nevergrad as ng

import importlib

from taskRecog.util import os_rmdirs,set_logger,set_fitset,set_dataloader
from taskRecog.Tuner import HyperTuner

from random import sample
import numpy as np
from copy import deepcopy
from numpy.random import uniform

def trial_str_creator(trial):
    return "{}_{}".format(trial.trainable_name, trial.trial_id)

def sigmoid_act(v):
    sv = 1 / (1+np.exp(-v))
    x = 1.0 if uniform(0, 1) > sv else 0.0
    return x

def mask_float(data_set, mask_op):
    '''
    data_set:(data, label)\n
    data:  torch.tensor (sample, dims, steps)\n
    im_op: list lens== steps
    '''
    data, label = data_set
    _data = data.detach().clone()

    for id, v in enumerate(mask_op):
        _data[:,:, id] = _data[:,:, id].detach().clone() * v

    new_data_set = (_data, label)
    
    return new_data_set

class maskTuner(HyperTuner):
    def __init__(self, opts = None, logger= None, data_opts = None, snr_list = None):
        super().__init__(opts, logger, data_opts)
        self.snr_list = snr_list

    def _gen_p2e(self,):
        config = {}
        Mask_list = ['inputMask_{}'.format(i) for i in range(self.hyper.sig_len)]
        for key in self.tuning.dict.keys():
            if key in self.hyper.dict:
                config[key] = self.hyper.dict[key]
            else:
                if key in Mask_list:
                    config[key] = 1
                
        # self.points_to_evaluate = [config]
        self.points_to_evaluate = []
        
        idx = [i for i in range(self.hyper.sig_len)]

        for mr in [0.05, 0.1, 0.15, 0.2]:
            num = int(self.hyper.sig_len * mr)
            for t in range(2):
                selected_idx = sample(idx, num)
                new_config = config.copy()
                for s_idx in selected_idx:
                    if 'soft_option' not in self.tuner.dict:
                        raise ValueError('Non found soft_option in tuner settings, please add this option in model_opts.tuner!')
                    
                    if self.tuner.soft_option == True:
                        new_config['inputMask_{}'.format(s_idx)] = np.random.random() * 2 # ~U[0,2)
                    else:
                        new_config['inputMask_{}'.format(s_idx)] = 0
                    
                self.points_to_evaluate.append(new_config)     

    def ray_conduct(self,):
        tuner_algo_dir = os.path.join(self.tuner.dir, self.algo_name)
        results_file_tag = os.path.join(tuner_algo_dir, 'tuner.pkl')
        if not os.path.exists(results_file_tag):
            func_data = self.pack_data()
            # ray.init(num_cpus=self.tuner.num_cpus)
            os.environ['RAY_COLOR_PREFIX'] = '1'
            ray.init()
            sched = ASHAScheduler(time_attr='training_iteration', max_t=self.tuner.max_training_iteration, grace_period= self.tuner.min_training_iteration) if self.using_sched else None
            # self.tuner.num_samples = 80
            tuner = tune.Tuner(
                tune.with_resources(
                    tune.with_parameters(maskTuningCell, data=func_data), 
                    resources=self.resource),
                param_space=self.tuning.dict,
                tune_config=
                tune.TuneConfig(
                search_alg=self.algo_func,
                metric='best_val_acc',
                mode="max",
                num_samples=self.tuner.num_samples,
                scheduler=sched,
                trial_name_creator=trial_str_creator,
                trial_dirname_creator=trial_str_creator,
                chdir_to_trial_dir = False,
                reuse_actors=True,
                # name=self.algo_name,
                # resources_per_trial=self.resource,
                # verbose=1,
                # raise_on_failed_trial = False
                ),
                run_config=RunConfig(
                    name=self.algo_name,
                    storage_path=self.tuner.dir,
                    verbose=1,
                    failure_config=FailureConfig(max_failures=self.tuner.num_samples // 2),
                    stop={'training_iteration':self.tuner.max_training_iteration,
                        #   'stop_counter': self.hyper.patience
                        },
                    checkpoint_config=CheckpointConfig(
                        num_to_keep=1,
                        checkpoint_at_end=False,
                        checkpoint_score_attribute ='val_acc',
                        checkpoint_score_order='max',
                        checkpoint_frequency= 0 # set to 0 to deactivate checkpoint
                    ),
                sync_config=tune.SyncConfig(syncer=None)      
                )
            )
            results = tuner.fit() 
            df = results.get_dataframe()
            df.to_csv(os.path.join(self.tuner.dir, '{}.trial.csv'.format(self.algo_name)))
            ray.shutdown()
            
        try:
            results_pt = os.path.join(tuner_algo_dir, 'hyper.tuning.pt' )
            self.best_config = torch.load(results_pt)
        except:
            try:
                analysis = ExperimentAnalysis(tuner_algo_dir)
                best_config = analysis.get_best_config(metric='val_acc', mode='max', scope='all')
                # best_trail = analysis.get_best_trial(metric='val_acc', mode='max', scope='all')
                best_trail_dir = analysis.get_best_logdir(metric='val_acc', mode='max', scope='all')
                best_config_path = os.path.join(best_trail_dir , 'hyper.pt')
                if os.path.exists(best_config_path):
                    best_saved_config = torch.load(best_config_path) #toDo: add check for saving hyper.pt in tuner.
                    self.best_config  = best_saved_config.dict
                else:
                    self.best_config = best_config
                
                torch.save(self.best_config, results_pt)
                if not os.path.exists(results_pt):
                    raise ValueError(f'Failed to save {results_pt}!')
            except:
                raise ValueError('Error in loading the tuning results in {}\nPlease check the tuning results carefully, then remove it and rerun.'.format(tuner_algo_dir))
        
        maskcode = {}
        for key in self.best_config.keys():
            if 'inputMask_' in key:
                maskcode[key] = self.best_config[key]
        
        assert len(list(maskcode.keys())) == self.data_opts.info.sig_len
        
        mask_idxs = []
        for i in range(self.data_opts.info.sig_len):
            mask_idxs.append(maskcode[f'inputMask_{i}'])  
            self.logger.info(f'inputMask_{i}: {mask_idxs[i]}')
        return mask_idxs
    

    def pack_data(self):
        # train_sig, train_label, _ = self.data_opts.snr_slice('train', snr)
        val_sig_list, val_lab_list = [], []
        for snr in self.snr_list:
            val_sig, val_lab, _ = self.data_opts.snr_slice('val', snr)
            val_sig_list.append(val_sig)
            val_lab_list.append(val_lab)

        val_sig_list = torch.cat(val_sig_list, dim=0)
        val_lab_list = torch.cat(val_lab_list, dim=0)
        func_data = Opt()
        func_data.logger = self.logger
        func_data.merge(self,['hyper', 'import_path', 'class_name', 'trainer_module'])
        # func_data.train_set = (None, None)
        func_data.val_set = (val_sig_list, val_lab_list)

        return func_data
    

        

class Praticle2fitness:
    def setup(self, data = None) -> None:
        self.init_data(data)

    def step(self,):
        self.trainer.before_val_step()
        for step, (sig_batch, lab_batch) in enumerate(self.trainer.val_loader):
            with torch.no_grad():
                sig_batch = sig_batch.to(self.trainer.hyper.device)
                lab_batch = lab_batch.to(self.trainer.hyper.device)

                loss, acc = self.trainer.cal_loss_acc(sig_batch, lab_batch)
                self.trainer.val_acc.update(acc)
        
        v_acc = self.trainer.val_acc.avg
        self.logger.info('Val Acc: {:.3f}%'.format(v_acc * 100 ))
        
        return {
            'val_acc': v_acc,
            'best_val_acc': v_acc * 100, 
        }
    
    def init_data(self, data):
        self.valid_data = data.val_set
        self.sample_hyper = data.hyper
        self.import_path = data.import_path
        self.class_name = data.class_name
        self.logger = data.logger
        # if 'logdir' not in self.__dict__:
        #     self.logdir = data.logdir

        # from pathlib import PurePath
        # p = PurePath(self.logdir)
        # p = p.parts
        
        # logger_path = os.path.join(self.logdir, '{}.log'.format(self.class_name))
        # self.logger = set_logger(logger_path, f'{self.class_name}.{p[-1]}.{p[-2]}', rewrite=False)
        self.problem_dim = self.sample_hyper.sig_len
        
        # self.num_workers = 0 if 'num_workers' not in self.sample_hyper.dict else  self.sample_hyper.num_workers        
        _model = importlib.import_module(self.import_path)
        _model = getattr(_model, self.class_name)
        sample_model = _model(self.sample_hyper, self.logger)
        
        self.logger.critical('Loading Model.')
        self.logger.critical(f'Model: \n{str(sample_model)}')
        self.logger.info(">>> Total params: {:.2f}M".format(
                    sum(p.numel() for p in list(sample_model.parameters())) / 1000000.0))
        self.logger.critical('Start fit.')
            
        trainer = importlib.import_module(data.trainer_module[0])
        trainer = getattr(trainer, data.trainer_module[1])
        
        val_loader = set_dataloader(batch_size= self.sample_hyper.batch_size, data_set=self.valid_data)
        
        self.logger.critical('Loading training set and validation set.')
        # self.logger.info(f"Train_loader batch: {len(train_loader)}")
        self.logger.info(f"Val_loader batch: {len(val_loader)}")
        self.logger.critical('>'*40)
        self.logger.info(f'Finding pretraining file in the location {self.sample_hyper.pretraining_allDatafile}')
        sample_model.load_pretraing_file(file_path=self.sample_hyper.pretraining_allDatafile)
        
        self.trainer = trainer(model = sample_model, train_loader = None, val_loader = val_loader, cfg = self.sample_hyper, logger = self.logger)
        # self.trainer.hyper.patience = self.trainer.hyper.epochs # Actually, in TuningCell, patience does not work as the same as in trainer.
        self.trainer.before_train()
    
    def reset_config(self, new_config):
        _config = Opt()
        _config.merge(new_config, ['inputMask_{}'.format(i) for i in range(self.sample_hyper.sig_len)])
        # torch.save(_config, os.path.join(self.logdir, 'hyper.pt'))
        
        inputMask = [_config.dict['inputMask_{}'.format(i)] for i in range(self.sample_hyper.sig_len)]
        val_set = mask_float(self.valid_data, inputMask)
        val_loader = set_dataloader(batch_size= self.sample_hyper.batch_size, data_set=val_set)
        self.logger.info(f"Reset config! Val_loader batch: {len(val_loader)}")
        self.logger.critical('>'*40)
        self.trainer.val_loader = val_loader
                
        return True
    
class maskTuningCell(Praticle2fitness, tune.Trainable):
    '''
    Trainable class of tuning stochastic neural network
    see https://docs.ray.io/en/latest/tune/examples/tune-pytorch-cifar.html#the-train-function
    '''
    def setup(self, config, data=None):
        self.init_data(data)
        # self.train_data = data.train_set
        self.reset_config(config)
    
    def save_checkpoint(self, tmp_checkpoint_dir):
        checkpoint_path = os.path.join(tmp_checkpoint_dir, "model.pth")
        torch.save(self.trainer.model.state_dict(), checkpoint_path)
        return tmp_checkpoint_dir

    def load_checkpoint(self, tmp_checkpoint_dir):
        checkpoint_path = os.path.join(tmp_checkpoint_dir, "model.pth")
        self.trainer.model.load_state_dict(torch.load(checkpoint_path))        
