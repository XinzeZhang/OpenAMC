import os
import sys

import torch
import numpy as np
from collections import Counter
from tqdm import tqdm, trange
from taskRecog.util import Opt, set_dataloader
# from taskRecog.Wrapper import Task
from taskRecog.Loader import TaskDataset
from taskRecog.Parser import get_parser

from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, cohen_kappa_score
from taskRecog.util import os_makedirs, os_rmdirs, set_logger, fix_seed
from taskRecog.util import save_training_process, save_confmat, save_snr_acc
from copy import deepcopy


from taskRecog.maskzeros_snr.hardmask.zerosMaskTuner import maskTuner
from taskRecog.maskzeros_snr.hardmask.zerosWrapper import ZerosMaskTask as Task

class Mask(Opt):

    def __init__(self, init=None):
        super().__init__(init)
        
        self.local_dir = ''
        self.name = ''


class ZerosMaskTask(Task):
    """Refer to Ensemble Wrapper Subsampling for Deep Modulation Classification, TCCN 2021.\n
    https://codeocean.com/capsule/8397297/tree/v1\n
    https://github.com/dl4amc/dds
    """

    def __init__(self, args):
        super().__init__(args)

    def snr_evoMask(self, snr = 0):
        # step_idxs = []
        
        tuner_dir = os.path.join(self.model_fit_dir, 'SNR_tuner', f'snr.{snr}')
        os_makedirs(tuner_dir)
        self.model_opts.tuner.dir = tuner_dir
        tLogger = self.logger_config(tuner_dir, 'tuning')
        
        snr_Tuner = maskTuner_oT(self.model_opts, logger= tLogger, subPack= self.data_opts, snr = snr)
        
        step_idxs = snr_Tuner.conduct()
        
        return step_idxs    
        
class maskTuner_oT(maskTuner):
    def __init__(self, opts = None, logger= None, subPack = None, snr = None):
        super().__init__(opts, logger, subPack, snr)


    def pack_data(self):
        
        # train_sig, train_label, _ = self.data_opts.snr_slice('train', snr)
        test_sig, test_lab, _ = self.data_opts.snr_slice('test', self.snr)

        func_data = Opt()
        # func_data.logger = self.logger
        func_data.merge(self,['hyper', 'import_path', 'class_name', 'trainer_module'])
        # func_data.train_set = (train_sig, train_label)
        func_data.val_set = (test_sig, test_lab)
        
        return func_data
            