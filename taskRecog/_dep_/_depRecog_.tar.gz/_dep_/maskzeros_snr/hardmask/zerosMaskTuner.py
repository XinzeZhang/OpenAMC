import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), os.path.pardir))

import torch
import torch.utils.data as Data

import ray
from taskRecog.util import Opt
# from ray.tune.suggest.bohb import TuneBOHB
# from ray.tune.schedulers import HyperBandForBOHB
from ray.tune.schedulers import ASHAScheduler
from ray.tune.schedulers import PopulationBasedTraining 
# https://arxiv.org/pdf/1711.09846.pdf.
from ray.tune.schedulers.pb2 import PB2 
# pip install GPy sklearn
# https://arxiv.org/abs/2002.02518 (NIPS 2020)
from ray import tune
from ray.air import session, FailureConfig
from ray.air.config import RunConfig
from ray.air.config import CheckpointConfig
# from ray.air.checkpoint import Checkpoint

from ray.tune.search.nevergrad import NevergradSearch
from ray.tune.search.ax import AxSearch
from ray.tune.search.optuna import OptunaSearch
from ray.tune.search import ConcurrencyLimiter
from ray.tune.search.basic_variant import BasicVariantGenerator
from ray.tune import ExperimentAnalysis

import nevergrad as ng

import importlib

from taskRecog.util import os_rmdirs,set_logger,set_fitset,set_dataloader
from taskRecog.Tuner import HyperTuner

from random import sample

def trial_str_creator(trial):
    return "{}_{}".format(trial.trainable_name, trial.trial_id)

def mask_zeros(data_set, mask_op):
    '''
    data_set:(data, label)\n
    data:  torch.tensor (sample, dims, steps)\n
    im_op: list lens== steps
    '''
    data, label = data_set
    _data = data.detach().clone()
    samples, dims = _data.size(0), _data.size(1)
    
    for id, tag in enumerate(mask_op):
        if int(tag) == 0:
            _data[:,:, id] = torch.zeros((samples, dims))
    
    new_data_set = (_data, label)
    
    return new_data_set

class maskTuner(HyperTuner):
    def __init__(self, opts = None, logger= None, subPack = None, snr = None):
        super().__init__(opts, logger, subPack)
        self.snr = snr


    def gen_p2e(self,):
        config = {}
        for key in self.tuning.dict.keys():
            config[key] = self.hyper.dict[key]
            
        self.points_to_evaluate = [config]
        
        idx = [i for i in range(self.hyper.sig_len)]
        tags = ['inputMask_{}'.format(i) for i in range(self.hyper.sig_len)]
        
        for mr in [0.05, 0.1, 0.15, 0.2]:
            num = int(self.hyper.sig_len * mr)
            for t in range(2):
                selected_idx = sample(idx, num)
                new_config = config.copy()
                for s_idx in selected_idx:
                    new_config['inputMask_{}'.format(s_idx)] = 0
                
                self.points_to_evaluate.append(new_config)
                

    def conduct(self,):
        tuner_algo_dir = os.path.join(self.tuner.dir, self.algo_name)
        results_pt = os.path.join(tuner_algo_dir, 'hyper.tuning.pt' )
        if not os.path.exists(results_pt):
            self._conduct()
            
        try:
            analysis = ExperimentAnalysis(tuner_algo_dir)
            best_config = analysis.get_best_config(metric='val_acc', mode='max', scope='all')
            # best_trail = analysis.get_best_trial(metric='val_acc', mode='max', scope='all')
            best_trail_dir = analysis.get_best_logdir(metric='val_acc', mode='max', scope='all')
            best_config_path = os.path.join(best_trail_dir , 'hyper.pt')
            if os.path.exists(best_config_path):
                best_config = torch.load(best_config_path) #toDo: add check for saving hyper.pt in tuner.
            self.best_config  = best_config.dict
            torch.save(self.best_config, os.path.join(tuner_algo_dir, 'hyper.tuning.pt'))
        except:
            raise ValueError('Error in loading the tuning results in {}\nPlease check the tuning results carefully, then remove it and rerun.'.format(tuner_algo_dir))
        
        maskcode = {}
        for key in self.best_config.keys():
            if 'inputMask_' in key:
                maskcode[key] = self.best_config[key]
        
        assert len(list(maskcode.keys())) == 128
        
        mask_idxs = []
        for i in range(128):
            if maskcode[f'inputMask_{i}'] == 0:
                mask_idxs.append(i)  

        return mask_idxs
    

    def pack_data(self):
        # train_sig, train_label, _ = self.data_opts.snr_slice('train', snr)
        val_sig, val_lab, _ = self.data_opts.snr_slice('val', self.snr)

        func_data = Opt()
        # func_data.logger = self.logger
        func_data.merge(self,['hyper', 'import_path', 'class_name', 'trainer_module'])
        # func_data.train_set = (None, None)
        func_data.val_set = (val_sig, val_lab)

        return func_data
    
    def _conduct(self,):
        
        func_data = self.pack_data()
        # ray.init(num_cpus=self.tuner.num_cpus)
        os.environ['RAY_COLOR_PREFIX'] = '1'
        ray.init()
        sched = ASHAScheduler(time_attr='training_iteration', max_t=self.tuner.max_training_iteration, grace_period= self.tuner.min_training_iteration) if self.using_sched else None
        # self.tuner.num_samples = 80
        tuner = tune.Tuner(
            tune.with_resources(
                tune.with_parameters(maskTuningCell, data=func_data), 
                resources=self.resource),
            param_space=self.tuning.dict,
            tune_config=
            tune.TuneConfig(
            search_alg=self.algo_func,
            metric='best_val_acc',
            mode="max",
            num_samples=self.tuner.num_samples,
            scheduler=sched,
            trial_name_creator=trial_str_creator,
            trial_dirname_creator=trial_str_creator,
            chdir_to_trial_dir = False,
            # name=self.algo_name,
            # resources_per_trial=self.resource,
            # verbose=1,
            # raise_on_failed_trial = False
            ),
            run_config=RunConfig(
                name=self.algo_name,
                storage_path=self.tuner.dir,
                verbose=1,
                failure_config=FailureConfig(max_failures=self.tuner.num_samples // 2),
                stop={'training_iteration':self.tuner.max_training_iteration,
                    #   'stop_counter': self.hyper.patience
                      },
                checkpoint_config=CheckpointConfig(
                    num_to_keep=1,
                    checkpoint_at_end=False,
                    checkpoint_score_attribute ='val_acc',
                    checkpoint_score_order='max',
                    checkpoint_frequency= 0 # set to 0 to deactivate checkpoint
                ),
            sync_config=tune.SyncConfig(syncer=None)      
            )
        )
        
        results = tuner.fit() 

        df = results.get_dataframe()
        df.to_csv(os.path.join(self.tuner.dir, '{}.trial.csv'.format(self.algo_name)))
        ray.shutdown()
        
        best_result = results.get_best_result(self.metric, 'max', scope='all')
        self.best_config.merge(best_result.config)


class maskTuningCell(tune.Trainable):
    '''
    Trainable class of tuning stochastic neural network
    see https://docs.ray.io/en/latest/tune/examples/tune-pytorch-cifar.html#the-train-function
    '''
    def setup(self, config, data=None):
        # self.train_data = data.train_set
        # self.valid_data = data.val_set
        self.base_hyper = data.hyper
        self.import_path = data.import_path
        self.class_name = data.class_name
        # self.logger = data.logger
        
        logger_path = os.path.join(self.logdir, '{}.log'.format(self.class_name))
        self.logger = set_logger(logger_path, f'{self.class_name}.tuning', rewrite=False)
        
        
        _hyper = Opt()
        _hyper.merge(self.base_hyper)
        _hyper.update(config) # Using ignore_unk will be very risky
        
        _config = Opt()
        _config.merge(config, ['inputMask_{}'.format(i) for i in range(self.base_hyper.sig_len)])
        torch.save(_config, os.path.join(self.logdir, 'hyper.pt'))
        
        
        self.sample_hyper = _hyper
        self.num_workers = 0 if 'num_workers' not in _hyper.dict else  _hyper.num_workers
        
        for i in range(_hyper.sig_len):
            if 'inputMask_{}'.format(i) not in _hyper.dict:
                raise ValueError('Missing hyper config: "inputMask_{}"!'.format(i))
            
        inputMask = [_hyper.dict['inputMask_{}'.format(i)] for i in range(_hyper.sig_len)]
        
        # train_set = mask_zeros(data.train_set, inputMask)
        val_set = mask_zeros(data.val_set, inputMask)
        
        # train_loader, val_loader = set_fitset(batch_size=_hyper.batch_size, train_set=train_set, val_set=val_set)
        
        val_loader = set_dataloader(batch_size= _hyper.batch_size, data_set=val_set)
        
        self.logger.critical('Loading training set and validation set.')
        # self.logger.info(f"Train_loader batch: {len(train_loader)}")
        self.logger.info(f"Val_loader batch: {len(val_loader)}")
        self.logger.critical('>'*40)
        
        _model = importlib.import_module(self.import_path)
        _model = getattr(_model, self.class_name)
        sample_model = _model(self.sample_hyper, self.logger)
        
        self.logger.critical('Loading Model.')
        self.logger.critical(f'Model: \n{str(sample_model)}')
        self.logger.info(">>> Total params: {:.2f}M".format(
                    sum(p.numel() for p in list(sample_model.parameters())) / 1000000.0))
        self.logger.critical('Start fit.')
            
        trainer = importlib.import_module(data.trainer_module[0])
        trainer = getattr(trainer, data.trainer_module[1])
        
        self.logger.info(f'Finding pretraining file in the location {self.sample_hyper.pretraining_allDatafile}')
        sample_model.load_pretraing_file(file_path=self.sample_hyper.pretraining_allDatafile)
        
        self.trainer = trainer(model = sample_model, train_loader = None, val_loader = val_loader, cfg = self.base_hyper, logger = self.logger)
        # self.trainer.hyper.patience = self.trainer.hyper.epochs # Actually, in TuningCell, patience does not work as the same as in trainer.
        self.trainer.before_train()
    
    def step(self,):
        self.trainer.before_val_step()
        for step, (sig_batch, lab_batch) in enumerate(self.trainer.val_loader):
            with torch.no_grad():
                sig_batch = sig_batch.to(self.trainer.hyper.device)
                lab_batch = lab_batch.to(self.trainer.hyper.device)

                loss, acc = self.trainer.cal_loss_acc(sig_batch, lab_batch)
                self.trainer.val_acc.update(acc)
        
        v_acc = self.trainer.val_acc.avg
        self.logger.info('Val Acc: {:.3f}%'.format(v_acc * 100 ))
        
        return {
            'val_acc': v_acc,
            'best_val_acc': v_acc * 100, 
        }
    
    def save_checkpoint(self, tmp_checkpoint_dir):
        checkpoint_path = os.path.join(tmp_checkpoint_dir, "model.pth")
        torch.save(self.trainer.model.state_dict(), checkpoint_path)
        return tmp_checkpoint_dir

    def load_checkpoint(self, tmp_checkpoint_dir):
        checkpoint_path = os.path.join(tmp_checkpoint_dir, "model.pth")
        self.trainer.model.load_state_dict(torch.load(checkpoint_path))        
        
            